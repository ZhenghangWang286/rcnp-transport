# rcnp-transport

Code accompanying **Resistance-conditioned neural polarization for three-dimensional transport through interacting thin layers**.

## Installation and execution

Use Python 3.12 and run the following commands from the repository root:

```bash
python -m pip install -r requirements.txt
python slab.py
python analyze.py
python plot.py
python test_core.py -v
```

`slab.py` evaluates neural polarization on a 4 x 6 x 4 grid with a dense nominal solve. It checks the polarization identity, operator contrast and interior-face conservation at a tolerance of 1e-10. `analyze.py` calculates paired comparisons from the 84-row evaluation table. `plot.py` writes `figures/comparison.pdf` and `figures/comparison.png`.

## Files

| Path | Contents |
| --- | --- |
| `core/model.py` | Eight-channel neural polarization model with 236 trainable parameters. |
| `core/polarization.py` | Conservative face operators, resistance coordinates and polarization correction. |
| `core/physics.py` | Differentiable field-response, wall-response and energy objective. |
| `checkpoints/balanced.pt` | Trained parameters for the balanced configuration. |
| `checkpoints/manifest.json` | Checkpoint digest, architecture and operating configuration. |
| `data/metrics.csv` | Metrics for 12 geometries evaluated with seven methods. |
| `data/README.md` | Metric definitions and measurement protocol. |
| `test_core.py` | Numerical, checkpoint, differentiation and data tests. |

## Formulation

For the actual operator A and nominal operator A0, define D = A0 - A and G = A0^(-1). With residual r and neural estimate e_hat, the corrected response is G[r + D e_hat]. Face and wall differences define D conservatively.

The network combines a transverse convolution, a pointwise convolution and trilinear interpolation. Checkpoint loading verifies its SHA-256 digest, operating configuration and parameter count, then loads the tensors with `weights_only=True`.

The checkpoint configuration `[3, 0, true]` records three PCG prefix steps, zero restarted PCG steps and an enabled nominal Green residual update. The learned polarization update uses this configuration. Physics-based fitting records `fine_training_labels` as zero.

Paired comparisons use geometry as the experimental unit. The analysis takes the median of within-geometry method ratios; the figure also reports their interquartile ranges.
