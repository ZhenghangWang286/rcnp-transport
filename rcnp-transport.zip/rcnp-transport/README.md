# Resistance-conditioned neural polarization

Code and experiment records accompanying **Resistance-conditioned neural polarization for three-dimensional transport through interacting thin layers**, by Zhenghang Wang, Baiying Dong and Tingfu Ma.

Resistance-conditioned neural polarization (RCNP) estimates the error in resistance coordinates and applies it through a conservative polarization operator. A shared 236-parameter network serves two deployment modes. **D** targets the discrete finite-volume solution; **R** adds a retained-coarse-state correction for the spatially refined target. Both modes finish with a scalar global-balance projection.

The repository provides numerical operators, trained weights, a slab calculation, experiment records, statistical analysis and comparison figures.

## Quick start

Use Python 3.12 in a virtual environment with CPU execution.

```bash
python -m venv .venv
```

Activate it with `.venv\Scripts\Activate.ps1` in Windows PowerShell, or `source .venv/bin/activate` on Linux/macOS. Then, from this directory:

```bash
python -m pip install -r requirements.txt
python verify.py
python slab.py
python analyze.py
python plot.py
python -m unittest discover -s tests -v
```

`verify.py` checks the file digests. `slab.py` loads the shared checkpoint and computes the neural correction and both numerical finishes on a 4 × 6 × 4 grid. It checks the polarization identity, conservative face action and global balance to a tolerance of 1e-10.

`analyze.py` recomputes 264 paired statistical summaries from 2,200 casewise metric records and verifies them against `data/paired_comparisons.csv`. The default output contains 132 comparisons for the prescribed D/64 and R/128 pairings. `plot.py` produces an eleven-metric comparison figure as PDF, editable SVG and 300 dpi PNG. Generated files go into `results/`.

```bash
python analyze.py --all-references --output results/all_comparisons.csv
python plot.py --cohort regression --output results/regression_comparison
python slab.py --output results/operator_checks.json
```

![Paired performance on the independent cohort](figures/comparison.png)

## Code map

| File | Mathematical role |
| --- | --- |
| `core/polarization.py` | Face-integrated resistance, resistance warp, conservative contrast action and the polarization identity, Eqs. (4)–(6) |
| `core/model.py` | Compact 8-channel, 236-parameter mixing network |
| `core/features.py` | Two-point coefficient context, native-grid physical directions, factorized interpolation and neural correction |
| `core/physics.py` | Differentiable response and energy objective, Eq. (9) |
| `core/finish.py` | Fixed-budget PCG, global-balance projection and retained-coarse-state correction, Eqs. (10)–(11) |
| `core/checkpoint.py` | CPU checkpoint loading and file/state digest validation |
| `slab.py` | End-to-end RCNP calculation and numerical identity checks |
| `analyze.py` | Paired ratios, stratified bootstrap intervals and statistical verification |
| `plot.py` | Comparison plots for the two geometry cohorts |

For residual `r`, nominal inverse `G`, actual operator `A` and nominal operator `A0`, the learned estimate enters through the face contrast:

```text
c = G[r + (A0 - A) e_hat]
e - c = G(A0 - A)(e - e_hat)

B(u) = u + sum(b - A u) / sum(A 1)
u_R = B[u_D + 0.25 P(R u_D - u_coarse)]
```

`P` is cell-centre interpolation with edge extrapolation; `R` is conservative 2 × 2 × 2 volume averaging. In `core/polarization.py`, interior face contributions cancel in the global sum, while the wall terms retain their physical contribution.

## Deployment settings

The experiments use a 64³ deployment grid and a retained 32³ coarse state. Both deployment modes use the same trained checkpoint.

| Setting | RCNP-D | RCNP-R |
| --- | --- | --- |
| Coarse relative tolerance | 1e-3 | Same as D |
| PCG prefix | 3 steps | Same as D |
| Neural correction | One application | Same as D |
| Numerical finish | 5 PCG steps, one Green correction, balance projection | D output, retained-coarse correction with alpha = 0.25, balance projection |
| Context quadrature | Two points per pooled x/z cell direction | Same as D |
| Face resistance quadrature | Four points | Same as D |
| Prescribed target | Converged 64³ finite-volume state | Conservative 64³ cell averages of the converged 128³ state |

`checkpoints/manifest.json` records these settings and the checkpoint digests. The 236 trainable parameters comprise 200 local-context parameters and 36 mixing-head parameters. The checkpoint was trained without fine-grid field labels.

`slab.py` uses a dense nominal solve on 96 cells. A prescribed field determines its right-hand side and retained coarse state for the numerical identity checks. The experiment tables report 64³ deployment results against the 64³ and projected 128³ reference states.

## Recorded results

The data contain eleven metrics for RCNP-D, RCNP-R and three controls: six-step preconditioned conjugate gradient (PCG), physics-direct and supervised-direct. Both reference grids are included for every method and geometry.

The independent cohort has 12 geometries and the regression cohort has eight, stratified by two, four, six or eight interacting sheets. Ratios are formed within each geometry before aggregation. The confidence intervals use 4,000 geometry-bootstrap resamples within the sheet-count strata. See [data/README.md](data/README.md) for fields, metrics, reference conventions and timing scope.

The figure shows all eleven outputs in the independent cohort. Circles denote D and diamonds denote R, each evaluated against its prescribed target. Points are paired median ratios and bars are pointwise 95% intervals; the dashed line is parity. The same plotting command accepts the regression cohort. [Figure details](figures/README.md).

## Citation and contact

Please cite the accompanying manuscript when using these methods or records. Author and software metadata are provided in `CITATION.cff`.

Correspondence: Tingfu Ma, School of Mathematics and Computer Science, Ningxia Normal University; tingfma@nxnu.edu.cn.

Project: <https://github.com/ZhenghangWang286/rcnp-transport>
