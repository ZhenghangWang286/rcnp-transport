"""Recompute paired ratios and stratified intervals from the released metrics."""

import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
COHORTS = {"independent": 12, "regression": 8}
CONTROLS = ("pcg6", "physics_direct", "supervised_direct")
METHODS = ("D", "R", *CONTROLS)
METRICS = (
    "heater_relative_l2", "global_relative_l2", "wall_flux_relative_l2",
    "energy_relative_error", "q8_relative_residual", "q8_global_balance_defect",
    "region_relative_l2", "peak_temperature_relative_error", "p99_temperature_relative_error",
    "source_mean_temperature_relative_error", "complete_call_seconds",
)
SUMMARY_FIELDS = ("cohort", "reference", "arm", "control", "metric", "paired_median_ratio",
                  "ci95_lower", "ci95_upper", "wins", "ties", "losses", "worst_ratio")


def load_metrics(path=DATA / "metrics.csv"):
    with Path(path).open(encoding="utf-8", newline="") as stream:
        records = list(csv.DictReader(stream))
    if len(records) != 2200:
        raise ValueError("Expected 2200 casewise metric records")
    rows, geometry = {}, {}
    for record in records:
        cohort, reference, arm, metric = (record[k] for k in ("cohort", "reference", "arm", "metric"))
        index, count = int(record["index"]), int(record["sheet_count"])
        if (cohort not in COHORTS or reference not in ("64", "128") or arm not in METHODS
                or metric not in METRICS or index not in range(COHORTS[cohort])):
            raise ValueError("Unrecognized cohort, reference, method or metric")
        key = (cohort, reference, index, arm, metric)
        if key in rows:
            raise ValueError("Duplicate casewise metric")
        value = float(record["value"])
        if not np.isfinite(value) or value < 0 or (metric == "complete_call_seconds" and value <= 0):
            raise ValueError("Metrics must be finite and nonnegative; times must be positive")
        if count != 2 * (index % 4 + 1):
            raise ValueError("Sheet-count stratum is inconsistent")
        identity = (count, record["geometry_hash"])
        if (cohort, index) in geometry and geometry[cohort, index] != identity:
            raise ValueError("Paired methods must share a geometry")
        geometry[cohort, index] = identity
        rows[key] = value
    expected = {(c, r, i, a, m) for c, n in COHORTS.items() for r in ("64", "128")
                for i in range(n) for a in METHODS for m in METRICS}
    if set(rows) != expected:
        raise ValueError("Incomplete paired evaluation grid")
    return rows


def paired_ratios(rows, cohort, reference, arm, control, metric):
    return np.array([rows[cohort, reference, i, arm, metric]
                     / max(rows[cohort, reference, i, control, metric], 1e-30)
                     for i in range(COHORTS[cohort])])


def summarize(rows):
    summaries = []
    for cohort, n in COHORTS.items():
        counts = 2 * (np.arange(n) % 4 + 1)
        rng = np.random.default_rng(20261011)
        samples = np.concatenate([rng.choice(np.flatnonzero(counts == k),
                                 size=(4000, np.sum(counts == k)), replace=True)
                                  for k in np.unique(counts)], axis=1)
        for reference in ("64", "128"):
            for arm in ("D", "R"):
                for control in CONTROLS:
                    for metric in METRICS:
                        ratios = paired_ratios(rows, cohort, reference, arm, control, metric)
                        low, high = np.quantile(np.median(ratios[samples], axis=1), [.025, .975])
                        summaries.append({
                            "cohort": cohort, "reference": reference, "arm": arm, "control": control,
                            "metric": metric, "paired_median_ratio": float(np.median(ratios)),
                            "ci95_lower": float(low), "ci95_upper": float(high),
                            "wins": int(np.sum(ratios < 1)), "ties": int(np.sum(ratios == 1)),
                            "losses": int(np.sum(ratios > 1)), "worst_ratio": float(np.max(ratios)),
                        })
    return summaries


def verify(summaries, directory=DATA):
    directory = Path(directory)
    manifest = json.loads((directory / "manifest.json").read_text(encoding="utf-8"))
    for record in manifest["files"]:
        path = directory / Path(record["target"]).name
        if hashlib.sha256(path.read_bytes()).hexdigest() != record["export_sha256"]:
            raise ValueError("Released data digest mismatch: " + path.name)
    with (directory / "paired_comparisons.csv").open(encoding="utf-8", newline="") as stream:
        expected = list(csv.DictReader(stream))
    identity = SUMMARY_FIELDS[:5]
    keyed = {tuple(row[k] for k in identity): row for row in expected}
    if len(expected) != 264 or len(keyed) != 264 or len(summaries) != 264:
        raise ValueError("Expected 264 unique paired summaries")
    for row in summaries:
        reference = keyed[tuple(row[k] for k in identity)]
        for key in SUMMARY_FIELDS[5:]:
            if not np.isclose(row[key], float(reference[key]), rtol=5e-13, atol=0):
                raise ArithmeticError(f"Paired summary differs for {row['cohort']}/{row['arm']}/{row['metric']}: {key}")
    return len(summaries)


def matched(summaries):
    return [r for r in summaries if (r["arm"], r["reference"]) in (("D", "64"), ("R", "128"))]


def write_summary(path, summaries):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=SUMMARY_FIELDS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(summaries)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--all-references", action="store_true", help="Write all 264 mode/reference combinations")
    parser.add_argument("--output", type=Path, default=ROOT / "results/paired_comparisons.csv")
    args = parser.parse_args()
    summaries = summarize(load_metrics())
    count = verify(summaries)
    selected = summaries if args.all_references else matched(summaries)
    write_summary(args.output, selected)
    print(f"Verified {count} paired summaries from 2200 metric records across 20 geometries.")
    print(f"Wrote {len(selected)} comparisons to {args.output}")


if __name__ == "__main__":
    main()
