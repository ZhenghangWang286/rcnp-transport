"""Calculate paired method ratios from casewise evaluation data."""

import csv
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "metrics.csv"
ARMS = ("balanced_amb", "matched_random", "full", "pcg6", "physics_direct",
        "supervised_direct", "end_to_end_direct")
METRICS = ("global_relative_l2", "energy_relative_error", "wall_flux_relative_l2",
           "complete_call_seconds")


def load_metrics():
    with DATA.open(newline="", encoding="utf-8") as stream:
        records = list(csv.DictReader(stream))
    if len(records) != 12 * len(ARMS):
        raise ValueError("Expected 12 geometries and seven methods")
    rows = {}
    for record in records:
        geometry = int(record["geometry_index"])
        arm = record["arm"]
        if geometry not in range(12) or arm not in ARMS or (geometry, arm) in rows:
            raise ValueError("Duplicate or unrecognized geometry/method")
        values = {metric: float(record[metric]) for metric in METRICS}
        if any(not np.isfinite(value) or value <= 0 for value in values.values()):
            raise ValueError("Metrics must be finite and positive")
        rows[geometry, arm] = {"sheet_count": int(record["sheet_count"]), **values}
    for geometry in range(12):
        if {rows[geometry, arm]["sheet_count"] for arm in ARMS} != {2 * (geometry % 4 + 1)}:
            raise ValueError("Sheet-count stratum is inconsistent")
        if not all((geometry, arm) in rows for arm in ARMS):
            raise ValueError("Missing paired method")
    return rows


def paired_ratios(rows, proposed, comparator, metric):
    return np.array([rows[i, proposed][metric] / rows[i, comparator][metric]
                     for i in range(12)], dtype=float)


def report():
    rows = load_metrics()
    summary = {"independent_geometries": 12, "methods": len(ARMS),
              "metric_unit": "median of within-geometry ratios",
              "comparisons": {}}
    for proposed in ("balanced_amb", "full"):
        summary["comparisons"][proposed] = {
            metric: float(np.median(paired_ratios(rows, proposed, "end_to_end_direct", metric)))
            for metric in METRICS
        }
    return summary


if __name__ == "__main__":
    print(json.dumps(report(), indent=2))
