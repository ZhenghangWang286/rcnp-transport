"""Neural polarization components."""
