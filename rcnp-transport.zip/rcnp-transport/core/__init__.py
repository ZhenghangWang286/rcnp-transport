"""Numerical components of resistance-conditioned neural polarization."""
