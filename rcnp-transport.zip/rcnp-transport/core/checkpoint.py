"""Load the shared D/R representation and verify its numerical identity."""

import hashlib
import json
from pathlib import Path

import torch

from .model import CompactInterfacePINN

CHECKPOINTS = Path(__file__).resolve().parents[1] / "checkpoints"


def state_digest(state):
    digest = hashlib.sha256()
    for name, tensor in sorted(state.items()):
        digest.update(name.encode("utf-8"))
        digest.update(tensor.detach().cpu().numpy().tobytes())
    return digest.hexdigest()


def load_model(directory=CHECKPOINTS):
    directory = Path(directory)
    manifest = json.loads((directory / "manifest.json").read_text(encoding="utf-8"))
    filename = manifest["file"]
    if Path(filename).name != filename:
        raise ValueError("Checkpoint filename must be relative to its directory")
    path = directory / filename
    if hashlib.sha256(path.read_bytes()).hexdigest() != manifest["file_sha256"]:
        raise ValueError("Checkpoint file digest does not match the manifest")
    state = torch.load(path, weights_only=True, map_location="cpu")
    if state_digest(state) != manifest["state_sha256"]:
        raise ValueError("Checkpoint state digest does not match the manifest")
    model = CompactInterfacePINN().eval()
    model.load_state_dict(state, strict=True)
    count = sum(parameter.numel() for parameter in model.parameters())
    if count != manifest["trainable_parameters"] or count != 236:
        raise ValueError("Unexpected neural parameter count")
    return model, manifest
