"""Eight-channel context and factorized inference for the compact model."""

import numpy as np
import torch
from torch.nn import functional as F

from .polarization import resistance_warp


def pool_xz(field):
    field = np.asarray(field, dtype=np.float32)
    nx, ny, nz = field.shape
    tx, tz = min(nx, 16), min(nz, 16)
    if nx % tx or nz % tz:
        raise ValueError("The x/z sizes must be divisible by their pooled sizes")
    return field.reshape(tx, nx // tx, ny, tz, nz // tz).mean(axis=(1, 4), dtype=np.float32)


def build_features(coefficient, operator, residual, response, nominal_conductance):
    """Construct quadrature2 context and four native-grid physical directions."""
    residual = np.asarray(residual, dtype=np.float64)
    response = np.asarray(response, dtype=np.float64)
    if residual.shape != operator.shape or response.shape != operator.shape:
        raise ValueError("Residual, response and operator grids must coincide")
    if not np.isfinite(residual).all() or not np.isfinite(response).all():
        raise ValueError("Residual and response must be finite")
    nx, ny, nz = response.shape
    scale = max(float(np.sqrt(np.mean(response ** 2))), 1e-15)
    rounded = response.astype(np.float32).astype(np.float64)
    warp, coordinate = resistance_warp(rounded, operator.transverse, nominal_conductance)
    difference = warp - rounded
    warp_scale = max(float(np.sqrt(np.mean(difference ** 2))), scale)
    x = (np.arange(nx)[:, None, None] + .5) / nx
    y = (np.arange(ny)[None, :, None] + .5) / ny
    directions = np.stack((response / scale, difference / warp_scale,
                           residual / operator.diagonal / scale,
                           np.broadcast_to(x, response.shape)), dtype=np.float32)
    tx, tz = min(nx, 16), min(nz, 16)
    offsets = np.array([-1., 1.]) / (2 * np.sqrt(3))
    qx = ((np.arange(tx)[:, None] + .5 + offsets[None]) / tx).ravel()
    qz = ((np.arange(tz)[:, None] + .5 + offsets[None]) / tz).ravel()
    sampled = np.asarray(coefficient(qx[:, None, None], y, qz[None, None, :]))
    if sampled.shape != (2 * tx, ny, 2 * tz) or not np.isfinite(sampled).all() or np.any(sampled <= 0):
        raise ValueError("The coefficient must be positive on the quadrature grid")
    log_coefficient = (np.log(sampled) / 4).reshape(tx, 2, ny, tz, 2).mean(axis=(1, 4)).astype(np.float32)
    pooled_shape = (tx, ny, tz)
    coordinates = (np.broadcast_to(((np.arange(tx) + .5) / tx)[:, None, None], pooled_shape),
                   np.broadcast_to(y, pooled_shape),
                   np.broadcast_to(((np.arange(tz) + .5) / tz)[None, None, :], pooled_shape))
    pooled = np.stack((pool_xz(directions[0]), pool_xz(directions[2]), log_coefficient,
                       pool_xz(directions[1]), pool_xz(coordinate), *coordinates), dtype=np.float32)
    return {"pooled": torch.from_numpy(pooled[None]),
            "directions": torch.from_numpy(directions[None]), "scale": scale,
            "residual": residual.astype(np.float32)}


def interpolate_xz(weights, shape):
    batch, _, _, ny, _ = weights.shape
    if batch != 1 or shape[1] != ny:
        raise ValueError("Interpolation requires one sample and an unchanged transverse grid")
    slices = weights[0].permute(2, 0, 1, 3).contiguous()
    enlarged = F.interpolate(slices, size=(shape[0], shape[2]), mode="bilinear", align_corners=False)
    return enlarged.permute(1, 2, 0, 3).unsqueeze(0).contiguous()


def estimate_error(model, sample):
    """Evaluate the four learned mixing fields on the native grid."""
    directions = sample["directions"]
    weights = model.mix(F.gelu(model.local(sample["pooled"])))
    weights = interpolate_xz(weights, directions.shape[-3:])
    return ((directions[:, :1] + (weights * directions).sum(1, keepdim=True))[0, 0]
            * sample["scale"])


def native_polarization(estimate, actual, nominal):
    """Apply the conservative contrast with the deployed float32 arithmetic."""
    if actual.shape != nominal.shape or any(getattr(actual, k) != getattr(nominal, k)
                                            for k in ("axial", "lateral", "reaction", "inlet_conductance")):
        raise ValueError("Actual and nominal bulk operators must coincide")
    estimate = np.asarray(estimate, dtype=np.float32)
    if estimate.shape != actual.shape:
        raise ValueError("The estimate must match the operator grid")
    transverse = nominal.transverse.astype(np.float32) - actual.transverse.astype(np.float32)
    jump = transverse * (estimate[:, 1:] - estimate[:, :-1])
    output = np.zeros_like(estimate)
    output[:, :-1] -= jump
    output[:, 1:] += jump
    output[:, 0] += (nominal.lower_wall.astype(np.float32) - actual.lower_wall.astype(np.float32)) * estimate[:, 0]
    output[:, -1] += (nominal.upper_wall.astype(np.float32) - actual.upper_wall.astype(np.float32)) * estimate[:, -1]
    return output


def neural_correction(model, sample, actual, nominal, nominal_solve):
    with torch.inference_mode():
        estimate = estimate_error(model, sample).numpy()
        forcing = sample["residual"] + native_polarization(estimate, actual, nominal)
    return nominal_solve(forcing.astype(np.float64)).astype(np.float32).astype(np.float64)
