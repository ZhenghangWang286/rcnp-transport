"""Finite-budget numerical finish and retained-coarse-state correction."""

import numpy as np


def restrict_volume(field):
    field = np.asarray(field)
    if field.ndim != 3 or any(n % 2 for n in field.shape):
        raise ValueError("An even three-dimensional grid is required")
    nx, ny, nz = (n // 2 for n in field.shape)
    return field.reshape(nx, 2, ny, 2, nz, 2).mean(axis=(1, 3, 5))


class GridTransfer:
    """Tensor-product linear interpolation with edge extrapolation."""

    def __init__(self, coarse_shape, fine_shape):
        self.coarse_shape, self.fine_shape = tuple(coarse_shape), tuple(fine_shape)
        if len(self.coarse_shape) != 3 or len(self.fine_shape) != 3:
            raise ValueError("Both grids must have three dimensions")
        self.axes = []
        for coarse, fine in zip(self.coarse_shape, self.fine_shape):
            if not isinstance(coarse, (int, np.integer)) or not isinstance(fine, (int, np.integer)) or min(coarse, fine) < 2:
                raise ValueError("Every direction needs at least two cell centres")
            centres = (np.arange(coarse) + .5) / coarse
            query = (np.arange(fine) + .5) / fine
            lower = np.clip(np.searchsorted(centres, query, side="right") - 1, 0, coarse - 2)
            self.axes.append((lower, (query - centres[lower]) * coarse))

    def __call__(self, coarse):
        result = np.asarray(coarse)
        if result.shape != self.coarse_shape:
            raise ValueError("The coarse field must match the transfer grid")
        for axis, ((lower, weight), nc, nf) in enumerate(zip(self.axes, self.coarse_shape, self.fine_shape)):
            if nc == nf:
                continue
            first, second = np.take(result, lower, axis=axis), np.take(result, lower + 1, axis=axis)
            shape = [1, 1, 1]
            shape[axis] = nf
            result = first + (second - first) * weight.reshape(shape)
        return result


def balance_project(state, rhs, operator):
    """Apply B(u) = u + 1^T(b - A u) / (1^T A 1)."""
    state, rhs = np.asarray(state, dtype=np.float64), np.asarray(rhs, dtype=np.float64)
    if state.shape != operator.shape or rhs.shape != operator.shape:
        raise ValueError("State and right-hand side must match the operator grid")
    denominator = float(operator.balance_denominator)
    if not np.isfinite(denominator) or denominator <= 0:
        raise ValueError("The balance denominator must be positive")
    shift = float((rhs - operator.matvec(state)).sum()) / denominator
    return state + shift


def pcg(operator, rhs, initial, nominal_solve, steps):
    """Execute a fixed number of preconditioned conjugate-gradient steps."""
    if not isinstance(steps, int) or steps < 0:
        raise ValueError("The iteration budget must be a nonnegative integer")
    state = np.array(initial, dtype=np.float64, copy=True)
    if steps == 0:
        return state
    shape = state.shape
    residual = (np.asarray(rhs, dtype=np.float64) - operator.matvec(state)).ravel()
    state = state.ravel()
    z = nominal_solve(residual.reshape(shape)).ravel()
    direction = z.copy()
    rz = float(residual @ z)
    for iteration in range(steps):
        if not np.isfinite(rz) or rz < 0:
            raise ArithmeticError("PCG requires a positive preconditioned residual norm")
        if rz < 1e-30:
            break
        action = operator.matvec(direction.reshape(shape)).ravel()
        denominator = float(direction @ action)
        if not np.isfinite(denominator) or denominator <= 0:
            raise ArithmeticError("PCG requires a positive-definite operator")
        alpha = rz / denominator
        state += alpha * direction
        residual -= alpha * action
        if iteration + 1 < steps:
            z = nominal_solve(residual.reshape(shape)).ravel()
            next_rz = float(residual @ z)
            direction = z + (next_rz / rz) * direction
            rz = next_rz
    return state.reshape(shape)


def discrete_finish(state, rhs, operator, nominal_solve, steps=5):
    state = pcg(operator, rhs, state, nominal_solve, steps)
    state += nominal_solve(rhs - operator.matvec(state))
    return balance_project(state, rhs, operator)


def refined_state(discrete_state, retained_coarse, rhs, operator, transfer, alpha=.25):
    """Apply B[u_D + alpha P(R u_D - u_coarse)]."""
    if not np.isfinite(alpha):
        raise ValueError("The spatial coefficient must be finite")
    coarse = restrict_volume(discrete_state)
    if np.shape(retained_coarse) != coarse.shape:
        raise ValueError("The retained state must match the restricted grid")
    direction = transfer(coarse - retained_coarse)
    return balance_project(discrete_state + alpha * direction, rhs, operator)
