"""Transverse-resolved neural polarization model."""

from torch import nn
from torch.nn import functional as F


class CompactInterfacePINN(nn.Module):
    def __init__(self):
        super().__init__()
        self.local = nn.Conv3d(8, 8, (1, 3, 1), padding=(0, 1, 0))
        self.mix = nn.Conv3d(8, 4, 1)
        nn.init.zeros_(self.mix.weight)
        nn.init.zeros_(self.mix.bias)

    def forward(self, features):
        nx, ny, nz = features.shape[-3:]
        pooled = F.adaptive_avg_pool3d(features, (min(16, nx), ny, min(16, nz)))
        weights = self.mix(F.gelu(self.local(pooled)))
        weights = F.interpolate(weights, size=(nx, ny, nz),
                                mode="trilinear", align_corners=False)
        directions = features[:, [0, 3, 1, 5]]
        return features[:, :1] + (weights * directions).sum(dim=1, keepdim=True)
