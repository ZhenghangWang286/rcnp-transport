"""Reference-free residual, wall-response and energy objective."""

import torch


def physics_objective(correction, residual, actual_action, nominal_solve,
                      wall_weight, field_scale, wall_scale, energy_scale):
    """Return field-response, wall-response and energy loss."""
    if any(float(value) <= 0 for value in (field_scale, wall_scale, energy_scale)):
        raise ValueError("Objective scales must be positive")
    defect = residual - actual_action(correction)
    response = nominal_solve(defect)
    global_term = response.square().mean() / field_scale
    wall_response = response[:, [0, -1], :] * wall_weight
    wall_term = wall_response.square().mean() / wall_scale
    energy = torch.sum(correction * (actual_action(correction) - 2 * residual)) / energy_scale
    return global_term + wall_term + 0.1 * energy
