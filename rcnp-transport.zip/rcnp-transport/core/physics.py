"""Differentiable physical response objective from manuscript Eq. (9)."""

import torch


def physics_objective(correction, residual, actual_action, nominal_solve,
                      wall_weight, field_variance, wall_variance, energy_scale):
    """The response denominators are squared scales; energy_scale is s_E."""
    scales = (field_variance, wall_variance, energy_scale)
    if any(not torch.isfinite(torch.as_tensor(value)) or float(value) <= 0 for value in scales):
        raise ValueError("Objective normalization scales must be positive and finite")
    defect = residual - actual_action(correction)
    response = nominal_solve(defect)
    global_term = response.square().mean() / field_variance
    wall_response = response[:, [0, -1], :] * wall_weight
    wall_term = wall_response.square().mean() / wall_variance
    energy = torch.sum(correction * (actual_action(correction) - 2 * residual)) / energy_scale
    return global_term + wall_term + .1 * energy
