"""Conservative slab operators, resistance coordinates and polarization corrections."""

from dataclasses import dataclass

import numpy as np


def resistance_warp(response, transverse, nominal_conductance):
    response = np.asarray(response, dtype=np.float64)
    transverse = np.asarray(transverse, dtype=np.float64)
    if response.ndim != 3 or transverse.shape != (
        response.shape[0], response.shape[1] - 1, response.shape[2]
    ):
        raise ValueError("Response and transverse-face shapes do not match")
    if (not np.all(np.isfinite(response)) or not np.all(np.isfinite(transverse))
            or not np.isfinite(nominal_conductance)
            or response.shape[1] < 2 or np.any(transverse <= 0) or nominal_conductance <= 0):
        raise ValueError("Face conductances must be positive")
    weights = nominal_conductance / transverse
    cumulative = np.concatenate((np.zeros_like(response[:, :1]),
                                  np.cumsum(weights, axis=1)), axis=1)
    coordinate = cumulative / cumulative[:, -1:, :]
    increments = np.diff(response, axis=1) * weights
    discrepancy = response[:, -1:, :] - response[:, :1, :] - increments.sum(axis=1, keepdims=True)
    increments += discrepancy * weights / weights.sum(axis=1, keepdims=True)
    warped = response[:, :1, :] + np.concatenate((np.zeros_like(response[:, :1]),
                                                 np.cumsum(increments, axis=1)), axis=1)
    return warped, coordinate


@dataclass
class FaceStencil:
    transverse: np.ndarray
    lower_wall: np.ndarray
    upper_wall: np.ndarray
    axial: float = 1.0
    lateral: float = 1.0
    reaction: float = 0.0
    inlet_conductance: float = 2.0

    def __post_init__(self):
        self.transverse = np.asarray(self.transverse, dtype=np.float64)
        self.lower_wall = np.asarray(self.lower_wall, dtype=np.float64)
        self.upper_wall = np.asarray(self.upper_wall, dtype=np.float64)
        if self.transverse.ndim != 3:
            raise ValueError("Transverse weights must have three dimensions")
        nx, between, nz = self.transverse.shape
        self.shape = (nx, between + 1, nz)
        if self.lower_wall.shape != (nx, nz) or self.upper_wall.shape != (nx, nz):
            raise ValueError("Wall-weight shapes do not match the slab")
        if min(self.shape) < 2 or np.any(self.transverse <= 0):
            raise ValueError("The slab needs positive internal face weights")
        if min(self.axial, self.lateral, self.inlet_conductance) <= 0 or self.reaction < 0:
            raise ValueError("Invalid bulk coefficient")
        if np.any(self.lower_wall < 0) or np.any(self.upper_wall < 0):
            raise ValueError("Wall weights must be nonnegative")
        arrays = (self.transverse, self.lower_wall, self.upper_wall)
        scalars = (self.axial, self.lateral, self.reaction, self.inlet_conductance)
        if any(not np.isfinite(value).all() for value in arrays) or not np.isfinite(scalars).all():
            raise ValueError("Operator coefficients must be finite")

    @property
    def diagonal(self):
        diagonal = np.full(self.shape, self.reaction)
        diagonal[:-1] += self.axial
        diagonal[1:] += self.axial
        diagonal[:, :, :-1] += self.lateral
        diagonal[:, :, 1:] += self.lateral
        diagonal[:, :-1] += self.transverse
        diagonal[:, 1:] += self.transverse
        diagonal[0] += self.inlet_conductance
        diagonal[:, 0] += self.lower_wall
        diagonal[:, -1] += self.upper_wall
        return diagonal

    @property
    def balance_denominator(self):
        _, ny, nz = self.shape
        return (self.reaction * np.prod(self.shape) + self.inlet_conductance * ny * nz
                + self.lower_wall.sum() + self.upper_wall.sum())

    def matvec(self, state):
        state = np.asarray(state, dtype=np.float64).reshape(self.shape)
        output = self.reaction * state.copy()
        jump = self.axial * (state[1:] - state[:-1])
        output[:-1] -= jump
        output[1:] += jump
        jump = self.lateral * (state[:, :, 1:] - state[:, :, :-1])
        output[:, :, :-1] -= jump
        output[:, :, 1:] += jump
        jump = self.transverse * (state[:, 1:] - state[:, :-1])
        output[:, :-1] -= jump
        output[:, 1:] += jump
        output[0] += self.inlet_conductance * state[0]
        output[:, 0] += self.lower_wall * state[:, 0]
        output[:, -1] += self.upper_wall * state[:, -1]
        return output

    def matrix(self):
        size = int(np.prod(self.shape))
        if size > 512:
            raise ValueError(f"Dense assembly supports at most 512 unknowns (received {size})")
        eye = np.eye(size)
        return np.column_stack([self.matvec(eye[:, j]).ravel() for j in range(size)])


def polarization_action(estimate, actual, nominal):
    """Apply D = A0 - A through face and wall differences."""
    if actual.shape != nominal.shape or any(
        getattr(actual, key) != getattr(nominal, key)
        for key in ("axial", "lateral", "reaction", "inlet_conductance")
    ):
        raise ValueError("The nominal and actual bulk operators must coincide")
    estimate = np.asarray(estimate, dtype=np.float64).reshape(actual.shape)
    jump = (nominal.transverse - actual.transverse) * (estimate[:, 1:] - estimate[:, :-1])
    output = np.zeros_like(estimate)
    output[:, :-1] -= jump
    output[:, 1:] += jump
    output[:, 0] += (nominal.lower_wall - actual.lower_wall) * estimate[:, 0]
    output[:, -1] += (nominal.upper_wall - actual.upper_wall) * estimate[:, -1]
    return output


def polarized_correction(residual, estimate, actual, nominal):
    """Evaluate G[r + D e_hat] with a dense nominal solve."""
    rhs = np.asarray(residual, dtype=np.float64).reshape(actual.shape)
    rhs = rhs + polarization_action(estimate, actual, nominal)
    return np.linalg.solve(nominal.matrix(), rhs.ravel()).reshape(actual.shape)
