# Casewise evaluation data

`metrics.csv` contains 84 rows: 12 geometries evaluated with seven methods. Each row identifies one geometry/method pair. Geometry is the experimental unit for paired comparisons. The two-, four-, six-, and eight-sheet groups each contain three geometries.

## Geometry and method fields

| Field | Description |
| --- | --- |
| `geometry_index` | Geometry identifier from 0 to 11. |
| `sheet_count` | Number of thin sheets: 2, 4, 6, or 8. |
| `arm` | Evaluation method identifier. |

| Method identifier | Description |
| --- | --- |
| `balanced_amb` | Balanced AMB operating configuration. |
| `matched_random` | Matched random-network control. |
| `full` | High-accuracy AMB operating configuration. |
| `pcg6` | Six-step PCG numerical control. |
| `physics_direct` | Direct neural method fitted with a physics objective. |
| `supervised_direct` | Direct neural method fitted with supervised targets. |
| `end_to_end_direct` | Finish-aligned direct neural method. |

## Metrics

Relative errors, residuals, and balance defects are dimensionless. Reference comparisons use the reference operator and solution on the same grid.

| Field | Description |
| --- | --- |
| `heater_relative_l2` | Relative L2 error in the heater output. |
| `global_relative_l2` | Relative L2 error in the temperature field. |
| `wall_flux_relative_l2` | Relative L2 error in the two wall-flux fields. |
| `energy_relative_error` | Relative error measured with the reference finite-volume energy operator. |
| `q8_relative_residual` | Relative residual against the eight-point-quadrature reference operator. |
| `q8_global_balance_defect` | Global balance defect against the eight-point-quadrature reference operator. |
| `region_relative_l2` | Relative L2 error in the regional thermal output. |
| `peak_temperature_relative_error` | Relative error in peak temperature. |
| `p99_temperature_relative_error` | Relative error in the 99th-percentile temperature. |
| `source_mean_temperature_relative_error` | Relative error in source-mean temperature. |
| `complete_call_seconds` | Median online evaluation-call time in seconds across seven warmed calls with balanced method order on the CPU host used in the study. |

The timing measurement covers the online evaluation call after warmup and fixed-resource loading. Offline training occurs before this measurement. Seven repeated calls produce one timing estimate for each geometry/method pair.

## Paired comparisons

`analyze.py` validates the 84 geometry/method pairs and sheet-count groups. For each metric, it divides the proposed method's value by the comparator's value within each geometry and then takes the median across the 12 geometries. `plot.py` plots these medians and their interquartile ranges. The manuscript describes the geometry generation, reference construction, and evaluation protocol.
