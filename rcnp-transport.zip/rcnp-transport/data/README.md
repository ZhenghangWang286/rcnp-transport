# Experiment data

The CSV files contain casewise measurements and paired statistical summaries for the independent and regression geometry cohorts.

## Files and schema

`metrics.csv` contains **2,200 rows**: 20 geometries × two reference grids × five methods × eleven metrics. Every combination is present. `paired_comparisons.csv` contains **264 summaries**: two cohorts × two references × two RCNP modes × three controls × eleven metrics.

| Column in `metrics.csv` | Meaning |
| --- | --- |
| `cohort` | `independent` (12 geometries) or `regression` (8 geometries) |
| `reference` | `64` or `128`, as defined below |
| `index` | Zero-based geometry index within the cohort |
| `sheet_count` | Number of interacting sheets: 2, 4, 6 or 8 |
| `geometry_hash` | Geometry identifier, shared across methods and references |
| `arm` | `D`, `R`, `pcg6`, `physics_direct` or `supervised_direct` |
| `metric` | One of the eleven keys below |
| `value` | Recorded error, defect or time; smaller values indicate better performance |

The `64` reference is the converged 64³ finite-volume state. The `128` reference is the conservative 64³ cell-average projection of the converged 128³ state. The prescribed comparisons pair D with `64` and R with `128`; the CSV retains both references for both modes. The balance defect, equation residual and runtime are reference-independent evaluations, so their values repeat across the two reference labels.

## Metrics

| Key | Output |
| --- | --- |
| `heater_relative_l2` | Relative L2 field error on the heater region |
| `global_relative_l2` | Relative L2 field error over the full domain |
| `wall_flux_relative_l2` | Relative L2 error of the wall-flux output |
| `energy_relative_error` | Relative energy-norm field error, sqrt(eᵀAe / u_refᵀAu_ref) |
| `q8_relative_residual` | Relative residual evaluated with the order-eight face-quadrature operator |
| `q8_global_balance_defect` | Absolute global residual sum, abs(sum(b − A8 u)) |
| `region_relative_l2` | Relative L2 error of the 64 volume-averaged temperatures on a fixed 4 × 4 × 4 domain partition |
| `peak_temperature_relative_error` | Relative error in peak temperature |
| `p99_temperature_relative_error` | Relative error in the 99th percentile of temperature |
| `source_mean_temperature_relative_error` | Relative error in the source-weighted mean temperature |
| `complete_call_seconds` | Complete online-call elapsed time, in seconds |

Region definitions, quadrature conventions and physical outputs follow the manuscript and Online Resource 1. The tables store the scalar outputs for each geometry, method and reference state.

## Paired analysis

For each geometry, the ratio is `RCNP value / max(control value, 1e-30)`. A ratio below one indicates a smaller RCNP value. `analyze.py` calculates the median of the ratios formed within each geometry.

Uncertainty is a pointwise 95% percentile interval for the paired median. Each bootstrap draw resamples geometries with replacement within each sheet-count stratum. The independent cohort has three geometries per stratum, and the regression cohort has two. The calculation uses 4,000 draws and NumPy seed `20261011`, reset for each cohort.

Summary rows include `paired_median_ratio`, `ci95_lower`, `ci95_upper`, `wins`, `ties`, `losses` and `worst_ratio`. Win/tie/loss counts compare each paired ratio with one.

## Timing

Each geometry/method time is the median of five calls, with a balanced five-method execution order. Across 20 geometries and five methods, the timing record comprises 500 calls. The host was an Intel Core i7-11390H under Windows with four computational threads.

The complete online call spans geometry construction through final-field and physical-output extraction. The `complete_call_seconds` column stores these measurements from the 64³ deployment experiments. `analyze.py` and `plot.py` calculate statistical summaries and figures from the recorded measurements.

## Integrity

`manifest.json` records cohort sizes, methods, bootstrap settings, timing scope and file digests. `analyze.py` validates the full Cartesian evaluation grid, pairing identities, numerical values and archived statistical summaries. The root-level `verify.py` also checks the complete release against `SHA256SUMS`.
