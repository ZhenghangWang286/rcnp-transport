# Paired comparison figure

`comparison.pdf`, `comparison.svg` and `comparison.png` show the independent cohort: twelve geometries with three geometries at each sheet count (2, 4, 6 and 8).

Each panel displays one of the eleven recorded metrics. The vertical labels identify the controls: PCG-6, physics-direct and supervised-direct. Teal circles are RCNP-D against the 64³ reference; purple diamonds are RCNP-R against the conservative projection of the 128³ reference. Points show the median within-geometry RCNP/control ratio. Horizontal bars show pointwise 95% percentile intervals from 4,000 geometry-bootstrap samples stratified by sheet count.

The horizontal axes are logarithmic and have panel-specific ranges. Each range includes the entire interval and the dashed parity line at one. Smaller ratios indicate smaller errors, defects or complete-call times. The figure is generated from the casewise experiment records in `data/metrics.csv`.

To regenerate it:

```bash
python plot.py --cohort independent --output results/comparison
```

Use `--cohort regression` for the corresponding eight-geometry cohort. Editable text is retained in the PDF and SVG; the PNG is exported at 300 dpi.
