"""Plot paired method comparisons from casewise evaluation data."""

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from analyze import ROOT, load_metrics, paired_ratios


CONTROLS = ("matched_random", "pcg6", "physics_direct", "supervised_direct",
            "end_to_end_direct", "full")
LABELS = ("Matched random", "PCG6", "Physics direct", "Supervised direct",
          "Finish-aligned direct", "AMB-full")
METRICS = ("global_relative_l2", "energy_relative_error", "wall_flux_relative_l2",
           "complete_call_seconds")
NAMES = ("Global field", "Discrete energy", "Wall flux", "Complete call")


def main():
    rows = load_metrics()
    plt.rcParams.update({"font.family": "sans-serif", "font.sans-serif": ["Arial", "DejaVu Sans"],
                         "font.size": 7.2, "axes.titlesize": 8.5, "axes.labelsize": 7.2,
                         "svg.fonttype": "none", "pdf.fonttype": 42,
                         "axes.spines.top": False, "axes.spines.right": False})
    figure, grid = plt.subplots(2, 2, figsize=(7.15, 5.9), sharey=True)
    axes = grid.ravel()
    figure.subplots_adjust(left=.25, right=.97, bottom=.12, top=.92, wspace=.23, hspace=.32)
    groups = ("#f0f4f5", "#edf3f2", "#f3f2ed", "#f3f2ed", "#f3f2ed", "#f1f3f6")
    for axis, letter, metric, heading in zip(axes, "abcd", METRICS, NAMES):
        for j, background in enumerate(groups):
            axis.axhspan(j - .48, j + .48, color=background, lw=0, zorder=0)
        axis.axvline(1, color="#607788", lw=.8, ls="--", zorder=1)
        for j, control in enumerate(CONTROLS):
            ratios = paired_ratios(rows, "balanced_amb", control, metric)
            median = float(np.median(ratios))
            low, high = np.quantile(ratios, (.25, .75))
            color = "#178f91" if median < 1 else "#ba684b"
            axis.plot((low, high), (j, j), lw=2.1, color=color, solid_capstyle="round", zorder=3)
            axis.scatter(median, j, s=25, color=color, edgecolor="white", lw=.5, zorder=4)
        axis.set_yticks(np.arange(6), LABELS)
        axis.set_ylim(5.48, -.48)
        axis.set_xlim(.35, 1.55 if metric != "complete_call_seconds" else 1.10)
        axis.set_xlabel("AMB-balanced / comparator")
        axis.grid(axis="x", color="#dce5e9", lw=.48, zorder=1)
        axis.set_title(f"{letter}  {heading}", loc="left", fontweight="bold", pad=7)
    figure.text(.53, .034, "Dots: median of 12 paired ratios   ·   bars: interquartile range   ·   dashed: parity",
                ha="center", fontsize=6.8, color="#607788")
    target = ROOT / "figures"
    target.mkdir(exist_ok=True)
    figure.savefig(target / "comparison.pdf", bbox_inches="tight", pad_inches=.10)
    figure.savefig(target / "comparison.png", dpi=300, bbox_inches="tight", pad_inches=.10)
    plt.close(figure)
    print(target / "comparison.pdf")


if __name__ == "__main__":
    main()
