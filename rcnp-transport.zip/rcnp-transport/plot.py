"""Plot all eleven paired outputs for either released geometry cohort."""

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import FixedLocator, FuncFormatter, NullLocator
import numpy as np

from analyze import COHORTS, CONTROLS, METRICS, ROOT, load_metrics, matched, summarize, verify

TITLES = (
    "Heater field error", "Global field error", "Wall-flux error",
    "Energy-norm error", "Equation residual", "Global balance defect",
    "Region-average error", "Peak temperature error", "P99 temperature error",
    "Source-mean temperature error", "Complete-call time",
)
COLORS = {"D": "#087F8C", "R": "#7750A6"}
MARKERS = {"D": "o", "R": "D"}


def ratio_ticks(low, high):
    if high / low < 2:
        return [round(value, 2) for value in np.arange(np.ceil(low * 10), np.floor(high * 10) + 1) / 10]
    if np.log10(high / low) > 3:
        powers = np.linspace(np.ceil(np.log10(low)), np.floor(np.log10(high)), 4).round().astype(int)
        return [10. ** power for power in np.unique(powers)]
    ticks = sorted({factor * 10. ** power
                    for power in range(int(np.floor(np.log10(low))), int(np.ceil(np.log10(high))) + 1)
                    for factor in (1, 2, 5) if low <= factor * 10. ** power <= high})
    if len(ticks) > 4:
        ticks = [ticks[i] for i in np.unique(np.linspace(0, len(ticks) - 1, 4).round().astype(int))]
    if 1. not in ticks:
        ticks = sorted([*ticks, 1.])
    return ticks


def create_figure(summaries, cohort="independent"):
    if cohort not in COHORTS:
        raise ValueError("Choose the independent or regression cohort")
    selected = [row for row in matched(summaries) if row["cohort"] == cohort]
    records = {(row["arm"], row["control"], row["metric"]): row for row in selected}
    if len(selected) != 66 or len(records) != 66:
        raise ValueError("The figure requires all 66 matched comparisons for one cohort")
    plt.rcParams.update({
        "font.family": "sans-serif", "font.sans-serif": ["DejaVu Sans"], "font.size": 8.5,
        "axes.labelsize": 8, "xtick.labelsize": 8, "ytick.labelsize": 8,
        "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none",
        "axes.linewidth": .65, "savefig.facecolor": "white",
    })
    fig, grid = plt.subplots(4, 3, figsize=(10.2, 10.6))
    fig.subplots_adjust(left=.104, right=.975, bottom=.065, top=.891, wspace=.62, hspace=.91)
    axes = grid.ravel()
    for index, (axis, metric, title) in enumerate(zip(axes, METRICS, TITLES)):
        values = [records[arm, control, metric] for arm in ("D", "R") for control in CONTROLS]
        low = min(row["ci95_lower"] for row in values)
        high = max(row["ci95_upper"] for row in values)
        if not 0 < low <= high < np.inf:
            raise ValueError("Logarithmic ratio intervals must be positive and finite")
        limits = (min(low, .96) / 1.22, max(high, 1.04) * 1.22)
        axis.set_xscale("log")
        axis.set_xlim(limits)
        axis.set_ylim(-.48, 2.48)
        axis.axvline(1., color="#92999F", linewidth=.85, linestyle=(0, (3, 3)), zorder=1)
        for arm, offset in (("D", .145), ("R", -.145)):
            for position, control in zip((2, 1, 0), CONTROLS):
                row = records[arm, control, metric]
                centre = row["paired_median_ratio"]
                lower, upper = row["ci95_lower"], row["ci95_upper"]
                if not lower <= centre <= upper:
                    raise ValueError("An interval does not contain its plotted median")
                axis.errorbar(centre, position + offset, xerr=[[centre - lower], [upper - centre]],
                              fmt=MARKERS[arm], color=COLORS[arm], markersize=4.1,
                              elinewidth=1.05, capsize=2.4, capthick=.8, zorder=3)
        axis.set_yticks([2, 1, 0], ["PCG-6", "Physics", "Supervised"])
        axis.tick_params(axis="y", length=0, pad=5)
        axis.tick_params(axis="x", length=3, pad=4)
        axis.xaxis.set_major_locator(FixedLocator(ratio_ticks(*limits)))
        axis.xaxis.set_major_formatter(FuncFormatter(lambda value, _: f"{value:g}"))
        axis.xaxis.set_minor_locator(NullLocator())
        axis.grid(axis="y", color="#E5E8EB", linewidth=.55, zorder=0)
        axis.spines[["top", "right", "left"]].set_visible(False)
        axis.spines["bottom"].set_color("#8B9299")
        axis.set_xlabel("RCNP / control", labelpad=4)
        axis.set_title(title, fontsize=9, loc="left", pad=17)
        axis.text(-.10, 1.17, chr(97 + index), transform=axis.transAxes,
                  fontsize=10, fontweight="bold", va="bottom", ha="right")
    legend = axes[-1]
    legend.axis("off")
    handles = [Line2D([], [], color=COLORS[arm], marker=MARKERS[arm], linewidth=1.1,
                      markersize=4.5, label=f"RCNP-{arm}") for arm in ("D", "R")]
    legend.legend(handles=handles, loc="upper left", frameon=False, fontsize=9,
                  handlelength=2, borderaxespad=0, bbox_to_anchor=(0, 1.18))
    legend.text(0, .65, "D: 64-cubed reference\nR: projected 128-cubed reference\n\n"
                "Points: paired medians\nBars: pointwise 95% intervals\nDashed line: equal performance\nLower ratios indicate smaller values",
                transform=legend.transAxes, fontsize=8, linespacing=1.55, va="top")
    name = "Independent" if cohort == "independent" else "Regression"
    fig.text(.037, .967, "RCNP paired performance", fontsize=15, fontweight="bold", color="#20303B")
    fig.text(.037, .938, f"{name} cohort · {COHORTS[cohort]} geometries · 3 controls · 11 metrics",
             fontsize=9, color="#465660")
    return fig, axes


def save_figure(fig, stem):
    stem = Path(stem)
    stem.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(stem.with_suffix(".pdf"), metadata={
        "Title": "RCNP paired performance", "Creator": "Matplotlib",
        "CreationDate": None, "ModDate": None,
    })
    fig.savefig(stem.with_suffix(".svg"))
    fig.savefig(stem.with_suffix(".png"), dpi=300)
    for extension in (".pdf", ".svg", ".png"):
        print(stem.with_suffix(extension))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cohort", choices=tuple(COHORTS), default="independent")
    parser.add_argument("--output", type=Path, help="Output filename stem, without an extension")
    args = parser.parse_args()
    summaries = summarize(load_metrics())
    verify(summaries)
    fig, _ = create_figure(summaries, args.cohort)
    save_figure(fig, args.output or ROOT / "results" / (args.cohort + "_comparison"))
    plt.close(fig)


if __name__ == "__main__":
    main()
