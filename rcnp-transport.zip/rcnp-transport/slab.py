"""Evaluate neural polarization and conservative face action on a slab."""

import hashlib
import json
from pathlib import Path

import numpy as np
import torch

from core.model import CompactInterfacePINN
from core.polarization import FaceStencil, polarization_action, polarized_correction, resistance_warp


ROOT = Path(__file__).resolve().parent


def slab_operators():
    nx, ny, nz = 4, 6, 4
    nominal_faces = np.full((nx, ny - 1, nz), 0.9)
    actual_faces = nominal_faces.copy()
    for i in range(nx):
        for k in range(nz):
            actual_faces[i, 2 + ((i + k) % 2), k] = 0.12
    lower = np.full((nx, nz), 0.25)
    upper = np.full((nx, nz), 0.30)
    common = {"axial": 1.1, "lateral": 0.6, "reaction": 0.02,
              "inlet_conductance": 2.2}
    actual = FaceStencil(actual_faces, lower, upper, **common)
    nominal = FaceStencil(nominal_faces, lower, upper, **common)
    return actual, nominal


def checkpoint_model():
    path = ROOT / "checkpoints" / "balanced.pt"
    manifest = json.loads((ROOT / "checkpoints" / "manifest.json").read_text(encoding="utf-8"))
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest != manifest["sha256"]:
        raise ValueError("Checkpoint digest does not match its manifest")
    saved = torch.load(path, weights_only=True, map_location="cpu")
    if tuple(saved["schedule"]) != tuple(manifest["selected_schedule"]):
        raise ValueError("Checkpoint schedule does not match its manifest")
    model = CompactInterfacePINN().eval()
    model.load_state_dict(saved["state_dict"], strict=True)
    if sum(parameter.numel() for parameter in model.parameters()) != 236:
        raise ValueError("Unexpected network size")
    return model


def evaluate_polarization():
    actual, nominal = slab_operators()
    nx, ny, nz = actual.shape
    x = (np.arange(nx)[:, None, None] + 0.5) / nx
    y = (np.arange(ny)[None, :, None] + 0.5) / ny
    z = (np.arange(nz)[None, None, :] + 0.5) / nz
    shape = actual.shape
    exact_error = 0.3 + np.sin(np.pi * x) * (0.6 + 0.2 * y) + 0.15 * z
    residual = actual.matvec(exact_error)
    nominal_matrix = nominal.matrix()
    response = np.linalg.solve(nominal_matrix, residual.ravel()).reshape(shape)
    warped, coordinate = resistance_warp(response, actual.transverse, 0.9)
    difference = warped - response
    scale = max(float(np.sqrt(np.mean(response**2))), 1e-15)
    warp_scale = max(float(np.sqrt(np.mean(difference**2))), scale)
    diagonal = np.diag(actual.matrix()).reshape(shape)
    face_log = np.zeros(shape)
    face_log[:, :-1] = np.log(actual.transverse / nominal.transverse)
    features = np.stack((response / scale, residual / diagonal / scale,
                         face_log / 4, difference / warp_scale, coordinate,
                         np.broadcast_to(x, shape), np.broadcast_to(y, shape),
                         np.broadcast_to(z, shape))).astype(np.float32)

    torch.set_num_threads(1)
    model = checkpoint_model()
    with torch.inference_mode():
        estimate = model(torch.from_numpy(features[None]))[0, 0].numpy().astype(np.float64) * scale
    correction = polarized_correction(residual, estimate, actual, nominal)
    right = np.linalg.solve(nominal_matrix,
                            polarization_action(exact_error - estimate, actual, nominal).ravel()
                            ).reshape(shape)
    identity_defect = float(np.linalg.norm(exact_error - correction - right))
    contrast_defect = float(np.linalg.norm(
        polarization_action(estimate, actual, nominal)
        - (nominal.matvec(estimate) - actual.matvec(estimate))))
    conservation_defect = float(abs(np.sum(polarization_action(estimate, actual, nominal))))
    if max(identity_defect, contrast_defect, conservation_defect) > 1e-10:
        raise ArithmeticError("Polarization identity or face conservation failed")
    return {"network_parameters": 236, "grid": list(shape),
            "identity_defect": identity_defect,
            "contrast_action_defect": contrast_defect,
            "interior_face_conservation_defect": conservation_defect}


if __name__ == "__main__":
    print(json.dumps(evaluate_polarization(), indent=2))
