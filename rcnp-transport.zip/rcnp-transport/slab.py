"""Check the RCNP operator identities and D/R finish on a 4 x 6 x 4 grid."""

import argparse
import json
from pathlib import Path

import numpy as np
import torch

from core.checkpoint import load_model
from core.features import build_features, estimate_error, neural_correction
from core.finish import GridTransfer, balance_project, discrete_finish, pcg, refined_state, restrict_volume
from core.polarization import FaceStencil, polarization_action, polarized_correction


def coefficient(x, y, z):
    first = .40 + .16 * (x - .5) - .08 * (z - .5)
    second = .62 - .12 * (x - .5) + .10 * (z - .5)
    return np.exp(-1.4 * np.exp(-.5 * ((y - first) / .045) ** 2)
                  -1.1 * np.exp(-.5 * ((y - second) / .055) ** 2))


def slab_operators(shape=(4, 6, 4)):
    nx, ny, nz = shape
    hx, hy, hz = 1 / nx, 1 / ny, 1 / nz
    epsilon, kx, kz, reaction = .0211051, .0285296, .0102895, .0234052
    x = (np.arange(nx)[:, None, None] + .5) / nx
    z = (np.arange(nz)[None, None, :] + .5) / nz
    nodes, weights = np.polynomial.legendre.leggauss(4)

    def resistance(left, right):
        total = np.zeros((nx, len(left), nz))
        for node, weight in zip(nodes, weights):
            y = ((left + right) / 2 + node * (right - left) / 2)[None, :, None]
            total += weight / coefficient(x, y, z)
        return total * ((right - left) / 2)[None, :, None]

    centres = (np.arange(ny) + .5) / ny
    transverse = epsilon * hx * hz / resistance(centres[:-1], centres[1:])
    lower_biot, upper_biot = 2.2, 1.7
    lower = epsilon * hx * hz / (resistance(np.array([0.]), np.array([hy / 2]))[:, 0] + 1 / lower_biot)
    upper = epsilon * hx * hz / (resistance(np.array([1 - hy / 2]), np.array([1.]))[:, 0] + 1 / upper_biot)
    nominal_conductance = epsilon * hx * hz / hy
    common = {"axial": kx * hy * hz / hx, "lateral": kz * hx * hy / hz,
              "reaction": reaction * hx * hy * hz, "inlet_conductance": 2 * kx * hy * hz / hx}
    actual = FaceStencil(transverse, lower, upper, **common)
    nominal = FaceStencil(np.full((nx, ny - 1, nz), nominal_conductance),
                          np.full((nx, nz), epsilon * hx * hz / (hy / 2 + 1 / lower_biot)),
                          np.full((nx, nz), epsilon * hx * hz / (hy / 2 + 1 / upper_biot)), **common)
    return actual, nominal


def evaluate():
    torch.set_num_threads(1)
    model, manifest = load_model()
    actual, nominal = slab_operators()
    nx, ny, nz = actual.shape
    x = (np.arange(nx)[:, None, None] + .5) / nx
    y = (np.arange(ny)[None, :, None] + .5) / ny
    z = (np.arange(nz)[None, None, :] + .5) / nz
    prescribed = .3 + np.sin(np.pi * x) * (.6 + .2 * y) + .15 * z
    rhs = actual.matvec(prescribed)
    nominal_matrix = nominal.matrix()

    def nominal_solve(value):
        return np.linalg.solve(nominal_matrix, value.ravel()).reshape(actual.shape)

    retained_coarse = restrict_volume(prescribed) * 1.02
    transfer = GridTransfer(retained_coarse.shape, actual.shape)
    state = pcg(actual, rhs, transfer(retained_coarse), nominal_solve,
                manifest["modes"]["D"]["pcg_prefix"])
    residual = rhs - actual.matvec(state)
    sample = build_features(coefficient, actual, residual, nominal_solve(residual),
                            float(nominal.transverse[0, 0, 0]))
    with torch.inference_mode():
        estimate = estimate_error(model, sample).numpy().astype(np.float64)
    exact_error = prescribed - state
    correction = polarized_correction(residual, estimate, actual, nominal)
    identity = exact_error - correction - nominal_solve(
        polarization_action(exact_error - estimate, actual, nominal))
    contrast = polarization_action(estimate, actual, nominal)
    wall_sum = ((nominal.lower_wall - actual.lower_wall) * estimate[:, 0]).sum()
    wall_sum += ((nominal.upper_wall - actual.upper_wall) * estimate[:, -1]).sum()
    contrast_defect = contrast - (nominal.matvec(estimate) - actual.matvec(estimate))
    state += neural_correction(model, sample, actual, nominal, nominal_solve)
    discrete = discrete_finish(state, rhs, actual, nominal_solve,
                               manifest["modes"]["D"]["pcg_finish"])
    refined = refined_state(discrete, retained_coarse, rhs, actual, transfer,
                             manifest["modes"]["R"]["alpha"])
    checks = {
        "polarization_identity": float(np.linalg.norm(identity)),
        "contrast_action": float(np.linalg.norm(contrast_defect)),
        "interior_face_conservation": float(abs(contrast.sum() - wall_sum)),
        "discrete_global_balance": float(abs((rhs - actual.matvec(discrete)).sum())),
        "refined_global_balance": float(abs((rhs - actual.matvec(refined)).sum())),
        "balance_idempotence": float(np.linalg.norm(balance_project(discrete, rhs, actual) - discrete)),
    }
    if max(checks.values()) > 1e-10:
        raise ArithmeticError("An operator identity failed its numerical tolerance")
    return {"grid": list(actual.shape), "neural_parameters": 236,
            "state_sha256": manifest["state_sha256"], "spatial_alpha": .25,
            "checks": checks, "tolerance": 1e-10}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Optional JSON report path")
    args = parser.parse_args()
    report = evaluate()
    text = json.dumps(report, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
    print(text, end="")


if __name__ == "__main__":
    main()
