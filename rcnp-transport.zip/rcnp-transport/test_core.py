"""Tests for neural polarization, physics differentiation and casewise metrics."""

import unittest

import numpy as np
import torch

from core.physics import physics_objective
from slab import checkpoint_model, evaluate_polarization, slab_operators
from core.polarization import polarization_action, resistance_warp
from analyze import load_metrics, paired_ratios, report


class PolarizationTests(unittest.TestCase):
    def test_model_and_checkpoint(self):
        model = checkpoint_model()
        self.assertEqual(sum(p.numel() for p in model.parameters()), 236)

    def test_resistance_warp_preserves_endpoints(self):
        actual, _ = slab_operators()
        field = np.arange(np.prod(actual.shape), dtype=float).reshape(actual.shape)
        warped, coordinate = resistance_warp(field, actual.transverse, 0.9)
        np.testing.assert_allclose(warped[:, 0], field[:, 0])
        np.testing.assert_allclose(warped[:, -1], field[:, -1])
        np.testing.assert_allclose(coordinate[:, 0], 0)
        np.testing.assert_allclose(coordinate[:, -1], 1)

    def test_contrast_and_identity(self):
        actual, nominal = slab_operators()
        field = np.random.default_rng(7).standard_normal(actual.shape)
        np.testing.assert_allclose(polarization_action(field, actual, nominal),
                                   nominal.matvec(field) - actual.matvec(field), atol=1e-12)
        self.assertLess(abs(np.sum(polarization_action(field, actual, nominal))), 1e-12)
        self.assertLess(evaluate_polarization()["identity_defect"], 1e-10)

    def test_physics_objective_is_differentiable(self):
        correction = torch.randn(2, 3, 2, requires_grad=True)
        residual = torch.ones_like(correction)
        wall_weight = torch.ones(2, 2, 2)
        objective = physics_objective(correction, residual, lambda value: 2 * value,
                                      lambda value: value / 3, wall_weight, 1.0, 1.0, 10.0)
        objective.backward()
        self.assertTrue(torch.isfinite(correction.grad).all())

    def test_case_metrics(self):
        rows = load_metrics()
        self.assertEqual(len(rows), 84)
        values = report()["comparisons"]
        targets = {
            "balanced_amb": (0.814575, 0.766822, 0.704839, 0.982385),
            "full": (0.612835, 0.552358, 0.503026, 1.081206),
        }
        names = ("global_relative_l2", "energy_relative_error", "wall_flux_relative_l2",
                 "complete_call_seconds")
        for arm, expected in targets.items():
            for metric, target in zip(names, expected):
                self.assertAlmostEqual(values[arm][metric], target, places=5)
        wins = sum(all(rows[i, "balanced_amb"][metric] < rows[i, "end_to_end_direct"][metric]
                       for metric in names[:2] + names[-1:]) for i in range(12))
        self.assertEqual(wins, 10)
        self.assertEqual(len(paired_ratios(rows, "full", "end_to_end_direct", names[0])), 12)


if __name__ == "__main__":
    unittest.main()
