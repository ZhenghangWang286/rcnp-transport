"""Numerical and data tests."""
