import csv
import io
import unittest
from unittest.mock import patch

import numpy as np

from analyze import DATA, METRICS, load_metrics, matched, paired_ratios, summarize, verify


class AnalysisTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows = load_metrics()
        cls.summaries = summarize(cls.rows)

    def test_all_published_pairings_recompute(self):
        self.assertEqual(verify(self.summaries), 264)
        self.assertEqual(len(matched(self.summaries)), 132)

    def test_every_metric_and_control_is_retained(self):
        self.assertEqual(len(self.rows), 2200)
        for cohort in ("independent", "regression"):
            for arm in ("D", "R"):
                selection = [s for s in matched(self.summaries) if (s["cohort"], s["arm"]) == (cohort, arm)]
                self.assertEqual(len(selection), 33)
                self.assertEqual({s["metric"] for s in selection}, set(METRICS))

    def test_geometry_is_the_pairing_unit(self):
        for summary in self.summaries:
            n = 12 if summary["cohort"] == "independent" else 8
            self.assertEqual(summary["wins"] + summary["ties"] + summary["losses"], n)
        ratios = paired_ratios(self.rows, "independent", "128", "R", "supervised_direct", "p99_temperature_relative_error")
        row = next(s for s in self.summaries if (s["cohort"], s["reference"], s["arm"], s["control"], s["metric"])
                   == ("independent", "128", "R", "supervised_direct", "p99_temperature_relative_error"))
        self.assertEqual(row["paired_median_ratio"], float(np.median(ratios)))
        self.assertEqual(row["wins"], int(np.sum(ratios < 1)))
        self.assertEqual(row["losses"], int(np.sum(ratios > 1)))

    def test_duplicate_record_is_rejected(self):
        lines = (DATA / "metrics.csv").read_text(encoding="utf-8").splitlines()
        lines[-1] = lines[1]
        with patch("pathlib.Path.open", return_value=io.StringIO("\n".join(lines))):
            with self.assertRaisesRegex(ValueError, "Duplicate"):
                load_metrics()

    def test_nonfinite_value_is_rejected(self):
        with (DATA / "metrics.csv").open(encoding="utf-8", newline="") as stream:
            reader = csv.DictReader(stream)
            fields, rows = reader.fieldnames, list(reader)
        rows[0]["value"] = "nan"
        stream = io.StringIO()
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
        with patch("pathlib.Path.open", return_value=io.StringIO(stream.getvalue())):
            with self.assertRaisesRegex(ValueError, "finite"):
                load_metrics()


if __name__ == "__main__":
    unittest.main()
