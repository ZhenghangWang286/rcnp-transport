import unittest

import numpy as np
import torch

from core.checkpoint import load_model, state_digest
from core.features import build_features, estimate_error, interpolate_xz
from core.finish import GridTransfer, balance_project, pcg, refined_state, restrict_volume
from core.physics import physics_objective
from core.polarization import FaceStencil, polarization_action, resistance_warp
from slab import coefficient, evaluate, slab_operators


class CoreTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1)
        cls.actual, cls.nominal = slab_operators()
        cls.model, cls.manifest = load_model()

    def test_checkpoint_identity_and_configuration(self):
        self.assertEqual(state_digest(self.model.state_dict()),
                         "cbf36405e4ed7250e1976b0dd509d096b05b2338be35e562a9f891a1bad7a36a")
        self.assertEqual(sum(p.numel() for p in self.model.parameters()), 236)
        self.assertEqual(self.manifest["modes"]["D"]["pcg_prefix"], 3)
        self.assertEqual(self.manifest["modes"]["D"]["pcg_finish"], 5)
        self.assertEqual(self.manifest["modes"]["R"]["alpha"], .25)

    def test_stencil_energy_and_diagonal(self):
        matrix = self.actual.matrix()
        np.testing.assert_allclose(matrix, matrix.T, atol=1e-15)
        self.assertGreater(np.linalg.eigvalsh(matrix).min(), 0)
        np.testing.assert_allclose(np.diag(matrix).reshape(self.actual.shape), self.actual.diagonal)
        self.assertAlmostEqual(matrix.sum(), self.actual.balance_denominator, places=13)

    def test_contrast_including_wall_terms(self):
        field = np.random.default_rng(7).standard_normal(self.actual.shape)
        contrast = polarization_action(field, self.actual, self.nominal)
        np.testing.assert_allclose(contrast, self.nominal.matvec(field) - self.actual.matvec(field), atol=1e-14)
        wall = np.sum((self.nominal.lower_wall - self.actual.lower_wall) * field[:, 0])
        wall += np.sum((self.nominal.upper_wall - self.actual.upper_wall) * field[:, -1])
        self.assertLess(abs(contrast.sum() - wall), 1e-14)

    def test_resistance_coordinates(self):
        field = np.random.default_rng(11).normal(size=self.actual.shape)
        warped, coordinate = resistance_warp(field, self.actual.transverse,
                                               float(self.nominal.transverse[0, 0, 0]))
        np.testing.assert_allclose(warped[:, 0], field[:, 0], atol=1e-14)
        np.testing.assert_allclose(warped[:, -1], field[:, -1], atol=1e-14)
        np.testing.assert_allclose(coordinate[:, 0], 0)
        np.testing.assert_allclose(coordinate[:, -1], 1)
        self.assertTrue((np.diff(coordinate, axis=1) > 0).all())

    def test_transfer_reproduces_affine_fields(self):
        coarse_shape, fine_shape = (2, 3, 2), (4, 6, 4)
        def affine(shape):
            axes = [(np.arange(n) + .5) / n for n in shape]
            return 1 + 2 * axes[0][:, None, None] - axes[1][None, :, None] + .3 * axes[2][None, None, :]
        transfer = GridTransfer(coarse_shape, fine_shape)
        np.testing.assert_allclose(transfer(affine(coarse_shape)), affine(fine_shape), atol=1e-15)
        np.testing.assert_allclose(restrict_volume(affine(fine_shape)), affine(coarse_shape), atol=1e-15)

    def test_transverse_interpolation_matches_trilinear(self):
        generator = torch.Generator().manual_seed(8)
        weights = torch.randn(1, 4, 4, 6, 4, generator=generator)
        expected = torch.nn.functional.interpolate(weights, size=(8, 6, 8), mode="trilinear", align_corners=False)
        torch.testing.assert_close(interpolate_xz(weights, (8, 6, 8)), expected, rtol=1e-6, atol=1e-6)

    def test_balance_projection_and_zero_alpha(self):
        rng = np.random.default_rng(17)
        rhs, state = rng.normal(size=(2, *self.actual.shape))
        balanced = balance_project(state, rhs, self.actual)
        self.assertLess(abs((rhs - self.actual.matvec(balanced)).sum()), 2e-13)
        np.testing.assert_allclose(balance_project(balanced, rhs, self.actual), balanced, atol=2e-14)
        coarse = restrict_volume(state)
        refined = refined_state(balanced, coarse, rhs, self.actual,
                                 GridTransfer(coarse.shape, state.shape), alpha=0)
        np.testing.assert_allclose(refined, balanced, atol=2e-14)

    def test_pcg_with_exact_preconditioner(self):
        rng = np.random.default_rng(20)
        rhs = rng.normal(size=self.actual.shape)
        matrix = self.actual.matrix()
        def inverse(value):
            return np.linalg.solve(matrix, value.ravel()).reshape(self.actual.shape)
        solved = pcg(self.actual, rhs, np.zeros_like(rhs), inverse, 1)
        np.testing.assert_allclose(solved, inverse(rhs), rtol=1e-13, atol=1e-13)
        np.testing.assert_array_equal(pcg(self.actual, np.zeros_like(rhs), np.zeros_like(rhs), inverse, 5), 0)

    def test_physics_gradient_by_finite_difference(self):
        generator = torch.Generator().manual_seed(23)
        value = torch.randn(2, 3, 2, dtype=torch.float64, generator=generator, requires_grad=True)
        residual = torch.randn(2, 3, 2, dtype=torch.float64, generator=generator)
        direction = torch.randn(2, 3, 2, dtype=torch.float64, generator=generator)
        def objective(x):
            return physics_objective(x, residual, lambda u: 2 * u, lambda u: u / 3,
                                      torch.ones(2, 2, 2, dtype=torch.float64), 1.2, .8, 10.)
        objective(value).backward()
        step = 1e-6
        finite = float((objective(value.detach() + step * direction) - objective(value.detach() - step * direction)) / (2 * step))
        self.assertAlmostEqual(float((value.grad * direction).sum()), finite, places=8)

    def test_feature_gradients_reach_the_shared_model(self):
        rng = np.random.default_rng(31)
        residual = rng.normal(size=self.actual.shape)
        response = np.linalg.solve(self.nominal.matrix(), residual.ravel()).reshape(self.actual.shape)
        sample = build_features(coefficient, self.actual, residual, response,
                                 float(self.nominal.transverse[0, 0, 0]))
        self.model.zero_grad(set_to_none=True)
        estimate_error(self.model, sample).square().mean().backward()
        for parameter in self.model.parameters():
            self.assertIsNotNone(parameter.grad)
            self.assertTrue(torch.isfinite(parameter.grad).all())
        self.assertGreater(float(self.model.mix.weight.grad.norm()), 0)

    def test_invalid_grid_and_coefficients(self):
        with self.assertRaises(ValueError):
            restrict_volume(np.zeros((3, 4, 4)))
        with self.assertRaises(ValueError):
            FaceStencil(np.full((2, 2, 2), np.nan), np.ones((2, 2)), np.ones((2, 2)))
        with self.assertRaises(ValueError):
            GridTransfer((1, 2, 2), (2, 4, 4))

    def test_end_to_end_operator_calculation(self):
        report = evaluate()
        self.assertTrue(all(v < report["tolerance"] for v in report["checks"].values()))


if __name__ == "__main__":
    unittest.main()
