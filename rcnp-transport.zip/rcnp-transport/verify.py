"""Check the SHA-256 digests of the files in this release."""

import hashlib
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent


def verify_release(root=ROOT):
    root = Path(root).resolve()
    checked = set()
    for line in (root / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        digest, relative = line.split("  ", 1)
        name = PurePosixPath(relative)
        if (name.is_absolute() or ".." in name.parts or "\\" in relative or ":" in relative
                or relative in checked or len(digest) != 64):
            raise ValueError("Invalid or repeated entry in SHA256SUMS")
        path = (root / Path(*name.parts)).resolve()
        if not path.is_relative_to(root):
            raise ValueError("Digest entry leaves the release directory")
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError("Digest mismatch or missing file: " + relative)
        checked.add(relative)
    if not checked:
        raise ValueError("Empty release manifest")
    return len(checked)


if __name__ == "__main__":
    count = verify_release()
    print(f"Verified {count} released files.")
